package Project.exception;

import java.sql.SQLException;

public class ProjectExeption extends Throwable {
    public ProjectExeption(String s, SQLException e) {
    }
}
